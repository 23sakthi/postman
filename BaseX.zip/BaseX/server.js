const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const admin = require('firebase-admin');

// Initialize Firebase
const serviceAccount = require('cloud83-firebase-adminsdk-jahzy-27a28d90db.json'); // Update with your service account path

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

const app = express();
const port = 8080;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Add a new train booking
app.post('/api/trains', async (req, res) => {
    const train = {
        ...req.body,
        id: Date.now().toString(), // Generate a unique ID based on timestamp
    };

    try {
        const docRef = await db.collection('trains').add(train);
        res.status(201).json({ id: docRef.id, ...train });
    } catch (error) {
        console.error('Error adding document: ', error);
        res.status(500).json({ error: 'Failed to create booking' });
    }
});

// Fetch all train bookings
app.get('/api/trains', async (req, res) => {
    try {
        const snapshot = await db.collection('trains').get();
        const trains = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        res.json(trains);
    } catch (error) {
        console.error('Error fetching documents: ', error);
        res.status(500).json({ error: 'Failed to fetch bookings' });
    }
});

// Fetch a single train booking by ID
app.get('/api/trains/:id', async (req, res) => {
    const trainId = req.params.id;

    try {
        const trainDoc = await db.collection('trains').doc(trainId).get();
        if (trainDoc.exists) {
            res.json({ id: trainDoc.id, ...trainDoc.data() });
        } else {
            res.status(404).json({ error: 'Booking not found' });
        }
    } catch (error) {
        console.error('Error fetching document: ', error);
        res.status(500).json({ error: 'Failed to fetch booking' });
    }
});

// Update a train booking by ID (only class and date)
app.put('/api/trains/:id', async (req, res) => {
    const trainId = req.params.id;

    try {
        await db.collection('trains').doc(trainId).update({
            date: req.body.date,
            class: req.body.class,
        });
        res.json({ id: trainId, ...req.body });
    } catch (error) {
        console.error('Error updating document: ', error);
        res.status(404).json({ error: 'Booking not found' });
    }
});

// Delete a train booking by ID
app.delete('/api/trains/:id', async (req, res) => {
    const trainId = req.params.id;

    try {
        await db.collection('trains').doc(trainId).delete();
        res.status(204).send();
    } catch (error) {
        console.error('Error deleting document: ', error);
        res.status(404).json({ error: 'Booking not found' });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
