const express = require('express');
const multer = require('multer');
const Dropbox = require('dropbox').Dropbox;
const fetch = require('isomorphic-fetch');
const path = require('path');

const app = express();
const port = 3000;

app.use(express.json()); // To parse JSON request bodies

// Set up multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// In-memory array to store patient data
let patients = [];

// Create a new patient (POST /api/patients)
app.post('/api/patients', upload.single('image'), async (req, res) => {
    const { id, name, doctor, medicine } = req.body;

    // Check if patient ID already exists
    if (patients.some(patient => patient.id === id)) {
        return res.status(400).json({ message: 'Patient with this ID already exists' });
    }

    const newPatient = { id, name, doctor, medicine };

    // Upload image to Dropbox if provided
    if (req.file) {
        try {
            const dbx = new Dropbox({ accessToken: 'sl.B-677kmjX6k0YPzIwYEELXXzVhX3eSmxDcFDfLTTTiGmZzqWHCuzwek6BRgNJu1gEa9MEctXivuf_kSmmOCjGUC3XNIiTJTH2dfYvb-eOgTSJfYdWYOj7I9tjke9-5xyZPEJXS2Ru-Gw', fetch });
            const dropboxPath = `/PatientImages/${req.file.originalname}`;
            await dbx.filesUpload({ path: dropboxPath, contents: req.file.buffer });
            newPatient.imageUrl = dropboxPath; // Save Dropbox path to patient data
        } catch (error) {
            console.error('Error uploading to Dropbox:', error);
            return res.status(500).json({ message: 'Failed to upload image to Dropbox' });
        }
    }

    patients.push(newPatient); // Add new patient to the array
    res.status(201).json(newPatient); // Return the newly added patient
});

// Read all patients (GET /api/patients)
app.get('/api/patients', (req, res) => {
    res.json(patients); // Return the list of patients
});

// Update a patient by ID (PUT /api/patients/:id)
app.put('/api/patients/:id', (req, res) => {
    const patientId = req.params.id;
    const { name, doctor, medicine } = req.body;

    const patientIndex = patients.findIndex(patient => patient.id === patientId);
    if (patientIndex === -1) {
        return res.status(404).json({ message: 'Patient not found' });
    }

    // Update patient information
    if (name) patients[patientIndex].name = name;
    if (doctor) patients[patientIndex].doctor = doctor;
    if (medicine) patients[patientIndex].medicine = medicine;

    res.json(patients[patientIndex]); // Return the updated patient
});

// Delete a patient by ID (DELETE /api/patients/:id)
app.delete('/api/patients/:id', (req, res) => {
    const patientId = req.params.id;

    const patientIndex = patients.findIndex(patient => patient.id === patientId);
    if (patientIndex === -1) {
        return res.status(404).json({ message: 'Patient not found' });
    }

    patients.splice(patientIndex, 1); // Remove patient from array
    res.json({ message: 'Patient deleted successfully' });
});

// Serve the frontend (index.html)
app.use(express.static(path.join(__dirname, 'public')));

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
