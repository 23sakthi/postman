const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// MongoDB connection URI
const uri = 'mongodb+srv://sarvani:Sarvani$2324@railwayscluster.1svsz.mongodb.net/?retryWrites=true&w=majority&appName=RailwaysCluster';

const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Route to add a new event
app.post('/add-event', async (req, res) => {
  try {
    const { Name, Email, Phone, EventName, EventDescription } = req.body;

    await client.connect();
    const database = client.db('EventManagement'); // Consistent database name
    const collection = database.collection('Events'); // Consistent collection name

    const newEvent = {
      Name,
      Email,
      Phone,
      EventName,
      EventDescription,
    };

    const result = await collection.insertOne(newEvent);
    res.send(`Event "${EventName}" added successfully!`);
  } catch (err) {
    res.status(500).send(`Error: ${err.message}`);
  } finally {
    await client.close();
  }
});

// Route to delete an event by name
app.post('/delete-event', async (req, res) => {
  try {
    const { EventName } = req.body;

    await client.connect();
    const database = client.db('EventManagement'); // Consistent database name
    const collection = database.collection('Events'); // Consistent collection name

    const result = await collection.deleteOne({ EventName });

    if (result.deletedCount > 0) {
      res.send(`Event "${EventName}" deleted successfully!`);
    } else {
      res.send(`Event "${EventName}" not found.`);
    }
  } catch (err) {
    res.status(500).send(`Error: ${err.message}`);
  } finally {
    await client.close();
  }
});

// Route to update the event description by name
app.post('/update-event', async (req, res) => {
  try {
    const { EventName, NewDescription } = req.body;

    await client.connect();
    const database = client.db('EventManagement'); // Consistent database name
    const collection = database.collection('Events'); // Consistent collection name

    const result = await collection.updateOne(
      { EventName },
      { $set: { EventDescription: NewDescription } }
    );

    if (result.matchedCount > 0) {
      res.send(`Event "${EventName}" updated with new description.`);
    } else {
      res.send(`Event "${EventName}" not found.`);
    }
  } catch (err) {
    res.status(500).send(`Error: ${err.message}`);
  } finally {
    await client.close();
  }
});

// Route to get all events
app.get('/events', async (req, res) => {
  try {
    await client.connect();
    const database = client.db('EventManagement'); // Consistent database name
    const collection = database.collection('Events'); // Consistent collection name

    const events = await collection.find({}).toArray();
    res.json(events);
  } catch (err) {
    res.status(500).send(`Error: ${err.message}`);
  } finally {
    await client.close();
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
