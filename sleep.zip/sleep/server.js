const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// In-memory event storage
let events = [];

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));  // Serve the static HTML, CSS, JS files from the 'public' directory

// Add a new event
app.post('/api/events', (req, res) => {
    const { name, phone, email, eventName, description } = req.body;

    // Validation
    if (!name || !phone || !email || !eventName || !description) {
        return res.status(400).send('All fields are required.');
    }

    // Check for duplicate phone number (assuming phone number is unique)
    const existingEvent = events.find(event => event.phone === phone);
    if (existingEvent) {
        return res.status(400).send('An event with this phone number already exists.');
    }

    // Create and store the new event
    const newEvent = { name, phone, email, eventName, description };
    events.push(newEvent);
    res.status(201).json(newEvent);
});

// Get all events
app.get('/api/events', (req, res) => {
    res.json(events);
});

// Update an event by phone number
app.put('/api/events/:phone', (req, res) => {
    const phone = req.params.phone;
    const { name, email, eventName, description } = req.body;

    const event = events.find(event => event.phone === phone);
    if (!event) {
        return res.status(404).send('Event not found.');
    }

    // Update only the provided fields
    if (name) event.name = name;
    if (email) event.email = email;
    if (eventName) event.eventName = eventName;
    if (description) event.description = description;

    res.json(event);
});

// Delete an event by phone number
app.delete('/api/events/:phone', (req, res) => {
    const phone = req.params.phone;
    const eventIndex = events.findIndex(event => event.phone === phone);

    if (eventIndex === -1) {
        return res.status(404).send('Event not found.');
    }

    // Remove the event from the array
    events.splice(eventIndex, 1);
    res.status(204).send();  // No content response for successful deletion
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
